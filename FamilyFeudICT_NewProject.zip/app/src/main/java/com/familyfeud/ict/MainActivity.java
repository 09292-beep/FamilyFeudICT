package com.familyfeud.ict;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;

public class MainActivity extends Activity {
    private final int NAVY=Color.rgb(7,21,47), PANEL=Color.rgb(18,43,83), GOLD=Color.rgb(255,213,79), WHITE=Color.WHITE;
    private LinearLayout root, card;
    private String player="";
    private String level="Easy";
    private int questionIndex=0, score=0;
    private boolean answered=false;
    private ArrayList<Question> questions=new ArrayList<>();
    private SharedPreferences prefs;

    static class Question {
        String q, correct;
        String[] choices;
        Question(String q,String correct,String... choices){this.q=q;this.correct=correct;this.choices=choices;}
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs=getSharedPreferences("familyfeud",MODE_PRIVATE);
        showHome();
    }

    private void setup(String title) {
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(20),dp(22),dp(20),dp(22)); root.setBackgroundColor(NAVY);
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.addView(root);
        setContentView(scroll);
        TextView heading=text(title,28,GOLD,true); heading.setGravity(Gravity.CENTER); root.addView(heading);
        TextView sub=text("15 QUESTIONS  •  3 LEVELS  •  PLAY & SCORE",13,WHITE,false); sub.setGravity(Gravity.CENTER); root.addView(sub);
        card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(18),dp(18),dp(18),dp(18));
        card.setBackground(round(PANEL,dp(18))); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.topMargin=dp(22); root.addView(card,lp);
    }

    private void showHome(){
        setup("FAMILY FEUD: ICT");
        addText(card,"Ready to play?",22,WHITE,true,0,12);
        addText(card,"Player name",14,WHITE,false,0,5);
        EditText name=new EditText(this); name.setSingleLine(true); name.setHint("Enter your name"); name.setTextColor(Color.BLACK); name.setHintTextColor(Color.GRAY);
        name.setPadding(dp(12),dp(8),dp(12),dp(8)); name.setBackground(round(WHITE,dp(10))); card.addView(name,new LinearLayout.LayoutParams(-1,dp(52)));
        addText(card,"Choose level",14,WHITE,false,0,5);
        Spinner spinner=new Spinner(this); String[] levels={"Easy — 1 point per correct answer","Medium — 2 points per correct answer","Hard — 3 points per correct answer"};
        spinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,levels)); card.addView(spinner);
        addText(card,"Each level has 5 questions. Choose the correct answer from the choices.",13,Color.LTGRAY,false,0,14);
        Button start=button("START GAME"); card.addView(start,match()); start.setOnClickListener(v->{
            player=name.getText().toString().trim(); if(player.isEmpty()){name.setError("Enter your name");return;}
            level=spinner.getSelectedItemPosition()==0?"Easy":spinner.getSelectedItemPosition()==1?"Medium":"Hard";
            score=0; questionIndex=0; answered=false; loadQuestions(); showQuestion();
        });
        Button leaderboard=button("LEADERBOARD"); card.addView(leaderboard,match()); leaderboard.setOnClickListener(v->showLeaderboard());
        addText(card,"Offline play supported • Scores saved on this phone",12,Color.LTGRAY,false,0,0);
    }

    private void loadQuestions(){
        questions.clear();
        if(level.equals("Easy")){
            questions.add(new Question("Which device is used to type text?","Keyboard","Keyboard","Monitor","Speaker"));
            questions.add(new Question("Which device displays computer output?","Monitor","Mouse","Monitor","Microphone"));
            questions.add(new Question("Which one is an input device?","Mouse","Printer","Speaker","Projector"));
            questions.add(new Question("What does CPU stand for?","Central Processing Unit","Computer Personal Unit","Central Program Utility","Control Power User"));
            questions.add(new Question("Which is used to print documents?","Printer","Scanner","Keyboard","Webcam"));
        } else if(level.equals("Medium")){
            questions.add(new Question("Which software is commonly used to make presentations?","Microsoft PowerPoint","Microsoft Paint","Calculator","Notepad"));
            questions.add(new Question("What does URL identify?","A web address","A computer battery","A type of keyboard","A printer setting"));
            questions.add(new Question("Which is an example of an operating system?","Windows","Google Chrome","Microsoft Word","Facebook"));
            questions.add(new Question("What is the purpose of RAM?","Temporarily store working data","Print files","Connect speakers","Scan documents"));
            questions.add(new Question("Which device connects a computer to a network?","Network adapter","Projector","Joystick","Plotter"));
        } else {
            questions.add(new Question("Which protocol is used to securely browse websites?","HTTPS","FTP","SMTP","HTTP"));
            questions.add(new Question("What does SQL primarily manage?","Relational databases","Image editing","Audio playback","Computer cooling"));
            questions.add(new Question("Which is a strong password practice?","Use a long unique password","Reuse one password everywhere","Share it with friends","Use your birthdate only"));
            questions.add(new Question("What is phishing?","A deceptive attempt to steal information","A computer backup","A programming language","A network cable"));
            questions.add(new Question("Which is the main purpose of an IP address?","Identify a device on a network","Increase screen brightness","Store documents","Protect a keyboard"));
        }
    }

    private void showQuestion(){
        setup("FAMILY FEUD: ICT");
        addText(card,player+"  •  "+level+"  •  "+(questionIndex+1)+"/5",15,GOLD,true,0,10);
        addText(card,"Score: "+score,18,WHITE,true,0,14);
        Question q=questions.get(questionIndex);
        addText(card,q.q,21,WHITE,true,0,18);
        ArrayList<String> opts=new ArrayList<>(Arrays.asList(q.choices)); Collections.shuffle(opts);
        for(String option:opts){
            Button b=button(option); card.addView(b,match());
            b.setOnClickListener(v->{
                if(answered)return; answered=true;
                if(option.equals(q.correct)){score+=level.equals("Easy")?1:level.equals("Medium")?2:3; b.setText("✓ "+option); b.setBackground(round(Color.rgb(35,130,80),dp(12)));}
                else {b.setText("✗ "+option); b.setBackground(round(Color.rgb(170,55,55),dp(12)));}
                for(int i=0;i<card.getChildCount();i++){View child=card.getChildAt(i); if(child instanceof Button) child.setEnabled(false);}
                addText(card,"Correct answer: "+q.correct,16,GOLD,true,0,12);
                Button next=button(questionIndex==4?"FINISH LEVEL":"NEXT QUESTION"); card.addView(next,match());
                next.setOnClickListener(v2->{questionIndex++; if(questionIndex>=5) finishLevel(); else showQuestion();});
            });
        }
        Button back=button("BACK TO HOME"); card.addView(back,match()); back.setOnClickListener(v->showHome());
    }

    private void finishLevel(){
        saveScore();
        setup("LEVEL COMPLETE!");
        addText(card,player,20,GOLD,true,0,12);
        addText(card,"Level: "+level,17,WHITE,true,0,8);
        addText(card,"Your score: "+score+" / "+(level.equals("Easy")?5:level.equals("Medium")?10:15),24,GOLD,true,0,18);
        Button home=button("HOME"); card.addView(home,match()); home.setOnClickListener(v->showHome());
        Button board=button("VIEW LEADERBOARD"); card.addView(board,match()); board.setOnClickListener(v->showLeaderboard());
    }

    private void saveScore(){
        try{
            JSONArray arr=new JSONArray(prefs.getString("scores","[]"));
            JSONObject obj=new JSONObject(); obj.put("name",player); obj.put("level",level); obj.put("score",score); obj.put("when",System.currentTimeMillis());
            arr.put(obj); prefs.edit().putString("scores",arr.toString()).apply();
        }catch(Exception ignored){}
    }

    private void showLeaderboard(){
        setup("LEADERBOARD");
        addText(card,"Best scores saved on this phone",14,Color.LTGRAY,false,0,12);
        try{
            JSONArray arr=new JSONArray(prefs.getString("scores","[]")); ArrayList<JSONObject> list=new ArrayList<>();
            for(int i=0;i<arr.length();i++)list.add(arr.getJSONObject(i));
            Collections.sort(list,(a,b)->Integer.compare(b.optInt("score"),a.optInt("score")));
            if(list.isEmpty())addText(card,"No scores yet. Play a level first!",16,WHITE,false,0,10);
            for(int i=0;i<Math.min(10,list.size());i++){
                JSONObject o=list.get(i); addText(card,(i+1)+". "+o.optString("name")+" — "+o.optInt("score")+" pts ("+o.optString("level")+")",16,WHITE,false,0,8);
            }
        }catch(Exception e){addText(card,"No scores yet.",16,WHITE,false,0,8);}
        Button home=button("HOME"); card.addView(home,match()); home.setOnClickListener(v->showHome());
    }

    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private void addText(LinearLayout parent,String s,int size,int color,boolean bold,int top,int bottom){TextView t=text(s,size,color,bold);t.setPadding(0,dp(top),0,dp(bottom));parent.addView(t);}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.rgb(20,30,50));b.setTextSize(15);b.setTypeface(null,Typeface.BOLD);b.setAllCaps(false);b.setBackground(round(GOLD,dp(12)));b.setPadding(dp(8),dp(7),dp(8),dp(7));return b;}
    private LinearLayout.LayoutParams match(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(7);p.bottomMargin=dp(7);return p;}
    private android.graphics.drawable.GradientDrawable round(int color,int radius){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(radius);return d;}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}
}